"use client";

import Link from "next/link";
import { useState } from "react";
import { Plus, Briefcase, Megaphone, CalendarPlus, UserPlus } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

type Action = { href: string; label: string; icon: typeof Plus };

const ACTIONS: Action[] = [
  { href: "/drives/new", label: "New drive", icon: Briefcase },
  { href: "/broadcasts", label: "New broadcast", icon: Megaphone },
  { href: "/events", label: "New event post", icon: CalendarPlus },
  { href: "/people", label: "Invite people", icon: UserPlus },
];

export function FloatingCreateButton() {
  const [open, setOpen] = useState(false);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger
        render={
          <button
            type="button"
            className="bg-primary text-primary-foreground fixed right-24 bottom-6 z-40 flex size-12 items-center justify-center rounded-full shadow-lg transition-transform hover:scale-105 print:hidden"
            aria-label="Quick create"
          >
            <Plus className="size-5" />
          </button>
        }
      />
      <PopoverContent align="end" side="top" className="w-52 p-1.5">
        <div className="flex flex-col">
          {ACTIONS.map((a) => (
            <Link
              key={a.href}
              href={a.href}
              onClick={() => setOpen(false)}
              className="hover:bg-accent flex items-center gap-2.5 rounded-md px-2.5 py-2 text-sm transition-colors"
            >
              <a.icon className="text-muted-foreground size-4" />
              {a.label}
            </Link>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
}
