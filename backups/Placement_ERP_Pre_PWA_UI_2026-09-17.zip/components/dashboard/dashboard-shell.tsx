"use client";

import { useState } from "react";
import Link from "next/link";
import { Menu, X } from "lucide-react";
import { cn } from "@/lib/utils";

export function DashboardShell({
  logo,
  nav,
  orgName,
  orgLogoUrl,
  headerCenter,
  headerRight,
  children,
}: {
  logo: React.ReactNode;
  nav: React.ReactNode;
  orgName: string;
  orgLogoUrl?: string | null;
  headerCenter?: React.ReactNode;
  headerRight: React.ReactNode;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);

  return (
    <div className="flex min-h-screen w-full">
      {open && (
        <div className="fixed inset-0 z-40 bg-black/30 md:hidden" onClick={() => setOpen(false)} aria-hidden />
      )}
      <aside
        className={cn(
          "bg-sidebar text-sidebar-foreground fixed inset-y-0 left-0 z-50 flex w-60 shrink-0 flex-col border-r px-3 py-5 transition-transform md:static md:translate-x-0 print:hidden",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="mb-7 flex items-center justify-between px-2">
          <Link href="/dashboard" className="flex items-center gap-2" onClick={() => setOpen(false)}>
            {logo}
          </Link>
          <button className="text-sidebar-foreground/60 md:hidden" onClick={() => setOpen(false)} aria-label="Close menu">
            <X className="size-4" />
          </button>
        </div>
        <div onClick={() => setOpen(false)}>{nav}</div>
      </aside>

      <div className="flex flex-1 flex-col">
        <header className="bg-background/80 flex h-14 items-center justify-between border-b px-4 backdrop-blur-sm sm:px-6 print:hidden">
          <div className="flex items-center gap-3">
            <button className="text-muted-foreground md:hidden" onClick={() => setOpen(true)} aria-label="Open menu">
              <Menu className="size-5" />
            </button>
            {orgLogoUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={orgLogoUrl} alt="" className="size-7 shrink-0 rounded-md object-cover ring-1 ring-border" />
            ) : (
              <span
                className="bg-accent text-accent-foreground flex size-7 shrink-0 items-center justify-center rounded-md text-xs font-semibold"
                aria-hidden
              >
                {orgName.charAt(0).toUpperCase()}
              </span>
            )}
            <span className="text-muted-foreground truncate text-sm font-medium">{orgName}</span>
          </div>
          {headerCenter && <div className="hidden flex-1 justify-center px-6 md:flex">{headerCenter}</div>}
          {headerRight}
        </header>
        <main className="flex-1 px-4 py-6 sm:px-6 sm:py-8">{children}</main>
      </div>
    </div>
  );
}
