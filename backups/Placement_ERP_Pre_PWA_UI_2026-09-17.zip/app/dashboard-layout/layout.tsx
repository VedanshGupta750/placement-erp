import Link from "next/link";
import { CalendarDays, Contact, Home, MessageCircleQuestion, MessageSquare } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { requireSession } from "@/lib/auth/session";
import { getTenantDb } from "@/lib/tenant/scoped-db";
import { hasPermission } from "@/lib/rbac/guard";
import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { SidebarNav } from "@/components/dashboard/sidebar-nav";
import { NotificationBell } from "@/components/dashboard/notification-bell";
import { ThemeToggle } from "@/components/dashboard/theme-toggle";
import { UserMenu } from "@/components/dashboard/user-menu";
import { CopilotWidget } from "@/components/ai/copilot-widget";
import { BatchSwitcher } from "@/components/dashboard/batch-switcher";
import { FloatingCreateButton } from "@/components/dashboard/floating-create-button";
import { GlobalSearch } from "@/components/dashboard/global-search";
import { BrandMark } from "@/components/tenant/brand-mark";
import { getActiveBatchId } from "@/lib/batch-context";
import { getBranding } from "@/lib/branding";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const session = await requireSession();
  const db = getTenantDb(session.collegeId);
  const branding = await getBranding();

  const user = await db.user.findUniqueOrThrow({
    where: { id: session.userId },
    select: {
      name: true,
      email: true,
      avatarUrl: true,
      userType: true,
      role: { select: { name: true } },
      college: { select: { name: true, logoUrl: true } },
      departmentMemberships: { select: { isAdmin: true } },
    },
  });

  let opportunitiesCount: number | undefined;
  if (user.userType === "STUDENT") {
    const student = await db.student.findUnique({ where: { userId: session.userId }, select: { id: true } });
    if (student) {
      opportunitiesCount = await db.application.count({ where: { studentId: student.id } }).then(async () => {
        // Eligible & open drives this student hasn't withdrawn from — kept
        // simple (course + policy match) rather than a full policy engine.
        const s = await db.student.findUnique({
          where: { id: student.id },
          select: { courseId: true, eligibleForPlacements: true },
        });
        if (!s?.eligibleForPlacements) return 0;
        return db.drive.count({
          where: { status: "PUBLISHED", eligibleCourses: { some: { courseId: s.courseId } } },
        });
      });
    }
  }

  const isAdmin = user.departmentMemberships.some((m) => m.isAdmin);
  const showCopilot = user.userType !== "STUDENT" && (await hasPermission(session, "report.view"));
  const canViewAudit = user.userType !== "STUDENT" && (await hasPermission(session, "audit.view"));
  const showStaffTools = user.userType !== "STUDENT";
  const canReviewExternalJobs = showStaffTools && (await hasPermission(session, "external_job.view"));
  const pendingExternalJobsCount = canReviewExternalJobs
    ? await db.externalJobReview.count({ where: { status: "PENDING" } })
    : undefined;
  const canViewFinance = showStaffTools && (await hasPermission(session, "finance.view"));

  let batches: { id: string; year: number }[] = [];
  let activeBatchId: string | null = null;
  if (showStaffTools) {
    [batches, activeBatchId] = await Promise.all([
      db.batch.findMany({ select: { id: true, year: true }, orderBy: { year: "desc" } }),
      getActiveBatchId(),
    ]);
  }

  return (
    <DashboardShell
      orgName={user.college.name}
      orgLogoUrl={user.college.logoUrl}
      logo={
        <>
          <BrandMark logoDataUri={branding.logoDataUri} className="size-7" />
          <span className="truncate text-[1.05rem] leading-none font-semibold tracking-tight">
            {branding.shortName}
          </span>
        </>
      }
      nav={
        <SidebarNav
          userType={user.userType}
          isAdmin={isAdmin}
          opportunitiesCount={opportunitiesCount}
          canViewAudit={canViewAudit}
          canReviewExternalJobs={canReviewExternalJobs}
          pendingExternalJobsCount={pendingExternalJobsCount}
          canViewFinance={canViewFinance}
        />
      }
      headerCenter={
        showStaffTools ? (
          <div className="flex w-full max-w-3xl items-center gap-3">
            <GlobalSearch />
            <div className="shrink-0">
              <BatchSwitcher batches={batches} activeBatchId={activeBatchId} />
            </div>
          </div>
        ) : undefined
      }
      headerRight={
        <div className="flex items-center gap-1.5">
          <Tooltip>
            <TooltipTrigger
              render={
                <Link
                  href="/dashboard"
                  className="text-muted-foreground hover:bg-accent hover:text-accent-foreground hidden size-8 items-center justify-center rounded-lg transition-colors sm:flex"
                  aria-label="Home"
                />
              }
            >
              <Home className="size-4" />
            </TooltipTrigger>
            <TooltipContent>Home</TooltipContent>
          </Tooltip>
          {showStaffTools && (
            <Tooltip>
              <TooltipTrigger
                render={
                  <Link
                    href="/contacts"
                    className="text-muted-foreground hover:bg-accent hover:text-accent-foreground hidden size-8 items-center justify-center rounded-lg transition-colors sm:flex"
                    aria-label="Contacts"
                  />
                }
              >
                <Contact className="size-4" />
              </TooltipTrigger>
              <TooltipContent>Contacts</TooltipContent>
            </Tooltip>
          )}
          <Tooltip>
            <TooltipTrigger
              render={
                <Link
                  href="/messages"
                  className="text-muted-foreground hover:bg-accent hover:text-accent-foreground hidden size-8 items-center justify-center rounded-lg transition-colors sm:flex"
                  aria-label="Messages"
                />
              }
            >
              <MessageSquare className="size-4" />
            </TooltipTrigger>
            <TooltipContent>Messages</TooltipContent>
          </Tooltip>
          <div className="bg-border mx-1 hidden h-6 w-px sm:block" />
          <Tooltip>
            <TooltipTrigger
              render={
                <a
                  href="/events"
                  className="text-muted-foreground hover:bg-accent hover:text-accent-foreground hidden size-8 items-center justify-center rounded-lg transition-colors sm:flex"
                  aria-label="Events calendar"
                />
              }
            >
              <CalendarDays className="size-4" />
            </TooltipTrigger>
            <TooltipContent>Events calendar</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger
              render={
                <a
                  href="mailto:support@placement-erp.local"
                  className="text-muted-foreground hover:bg-accent hover:text-accent-foreground hidden size-8 items-center justify-center rounded-lg transition-colors sm:flex"
                  aria-label="Help"
                />
              }
            >
              <MessageCircleQuestion className="size-4" />
            </TooltipTrigger>
            <TooltipContent>Help & support</TooltipContent>
          </Tooltip>
          <ThemeToggle />
          <NotificationBell />
          <div className="bg-border mx-1 hidden h-6 w-px sm:block" />
          <UserMenu name={user.name} email={user.email} role={user.role?.name ?? user.userType} avatarUrl={user.avatarUrl} />
        </div>
      }
    >
      {children}
      {showStaffTools && <FloatingCreateButton />}
      {showCopilot && <CopilotWidget />}
    </DashboardShell>
  );
}
